$nodeDir = 'C:\Program Files\nodejs'
$nodeExe = Join-Path $nodeDir 'node.exe'
$npmCmd = Join-Path $nodeDir 'npm.cmd'

if (-not (Test-Path $nodeExe) -or -not (Test-Path $npmCmd)) {
  Write-Error "Node.js was not found in $nodeDir. Install Node.js or update start-app.ps1."
  exit 1
}

$env:Path = "$nodeDir;$env:Path"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$backendDir = Join-Path $projectRoot 'backend'
$frontendDir = Join-Path $projectRoot 'frontend'

function Test-Url {
  param([string]$Url)

  try {
    Invoke-WebRequest -UseBasicParsing $Url | Out-Null
    return $true
  } catch {
    return $false
  }
}

function Start-ServiceIfNeeded {
  param(
    [string]$Name,
    [string]$WorkingDirectory,
    [string[]]$ArgumentList,
    [string]$HealthUrl
  )

  if (Test-Url $HealthUrl) {
    Write-Host "$Name is already running at $HealthUrl"
    return
  }

  Start-Process -FilePath $npmCmd -ArgumentList $ArgumentList -WorkingDirectory $WorkingDirectory -WindowStyle Hidden | Out-Null

  for ($i = 0; $i -lt 20; $i++) {
    Start-Sleep -Milliseconds 750
    if (Test-Url $HealthUrl) {
      Write-Host "$Name started at $HealthUrl"
      return
    }
  }

  Write-Warning "$Name did not become ready at $HealthUrl. Try starting it manually from $WorkingDirectory."
}

Start-ServiceIfNeeded -Name 'Backend' -WorkingDirectory $backendDir -ArgumentList @('run', 'dev') -HealthUrl 'http://127.0.0.1:5005/health'
Start-ServiceIfNeeded -Name 'Frontend' -WorkingDirectory $frontendDir -ArgumentList @('run', 'dev', '--', '--host', '0.0.0.0') -HealthUrl 'http://127.0.0.1:5174'

Write-Host ''
Write-Host 'Frontend: http://127.0.0.1:5174'
Write-Host 'Backend:  http://127.0.0.1:5005/health'
