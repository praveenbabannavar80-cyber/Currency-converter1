# Currency Converter Web Application

A professional, real-time currency conversion tool built with a modern full-stack architecture.

## 🚀 Features

- **Real-time Rates**: Fetches live global exchange rates via a proxy backend.
- **Modern UI**: Clean, responsive interface built with React and Tailwind CSS v4.
- **Dark Mode**: Support for light and dark themes with persistence.
- **Conversion History**: Automatically saves the last 5 conversions for quick reference.
- **Robust Validation**: Prevents invalid inputs (e.g., negative amounts).
- **Decoupled Architecture**: Separate frontend and backend for scalability and security.

## 🛠️ Tech Stack

- **Frontend**: React (Vite), Tailwind CSS v4, Lucide React, Axios.
- **Backend**: Node.js, Express, Axios, CORS.
- **Documentation**: Microsoft Word (.docx).

## 📁 Project Structure

```text
.
├── frontend/               # React application (Vite)
├── backend/                # Node.js Express server
├── Currency_Converter_Documentation.docx  # Academic documentation
├── Currency_Converter_Project.zip         # Project archive
└── README.md               # This file
```

## ⚙️ Installation & Setup

### 1. Prerequisites
- Node.js (v18 or higher)
- npm

### 2. Backend Setup
```bash
cd backend
npm install
npm run dev
```
The backend will run on `http://localhost:5005`.

### 3. Frontend Setup
```bash
cd frontend
npm install
npm run dev
```
The frontend will run on `http://localhost:5174`.

## 📖 Academic Requirements

This project fulfills both Functional and Non-Functional requirements for a standard Software Engineering academic record:
- **Functional**: Amount input, currency selection, instant conversion, swap feature, reset feature, history log.
- **Non-Functional**: Performance, usability, mobile responsiveness, error handling, reliability.

## 📄 Documentation

A full academic report is included in the root directory: [Currency_Converter_Documentation.docx](./Currency_Converter_Documentation.docx). It covers the Software Process Model (Agile), SRS, DFDs, Use Case Diagrams, Activity Diagrams, and Sequence Diagrams.

## 🤝 Team
- [Name Placeholder 1]
- [Name Placeholder 2]
- [Name Placeholder 3]

---
Created as an Academic Project for [Course Name].
