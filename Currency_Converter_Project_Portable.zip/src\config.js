const envApiBaseUrl = import.meta.env.VITE_API_BASE_URL;
const apiHost = window.location.hostname || 'localhost';
const apiProtocol = window.location.protocol || 'http:';

const apiBaseUrl = envApiBaseUrl || `${apiProtocol}//${apiHost}:5005`;

export const API_URL = `${apiBaseUrl}/api`;
