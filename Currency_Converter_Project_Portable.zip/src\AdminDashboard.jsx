import React, { useState, useEffect } from 'react';
import {
  Users, 
  DollarSign, 
  LogOut, 
  Plus, 
  Pencil, 
  Trash2, 
  X,
  Check,
  Loader2,
  LayoutDashboard,
  LogIn,
  History
} from 'lucide-react';
import {
  addAdminUser,
  addCurrency,
  deleteAdminUser,
  deleteCurrency,
  forceLogout,
  getAdminCurrencies,
  getAdminUsers,
  getLoggedInUsers,
  getUserConversionHistory,
  updateAdminUser,
  updateCurrency,
} from './apiStore';

function AdminDashboard({ admin, onLogout }) {
  const [activeTab, setActiveTab] = useState('users');
  const [users, setUsers] = useState([]);
  const [currencies, setCurrencies] = useState([]);
  const [loggedInUsers, setLoggedInUsers] = useState([]);
  const [conversionHistory, setConversionHistory] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  // Form states
  const [showUserModal, setShowUserModal] = useState(false);
  const [showCurrencyModal, setShowCurrencyModal] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [editingCurrency, setEditingCurrency] = useState(null);
  
  // User form
  const [userForm, setUserForm] = useState({ email: '', name: '', password: '' });
  // Currency form
  const [currencyForm, setCurrencyForm] = useState({ code: '', name: '', flag: '' });

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    setError('');
    try {
      if (activeTab === 'users') {
        setUsers(await getAdminUsers());
      } else if (activeTab === 'currencies') {
        setCurrencies(await getAdminCurrencies());
      } else if (activeTab === 'loggedIn') {
        setLoggedInUsers(await getLoggedInUsers());
      } else if (activeTab === 'history') {
        setUsers(await getAdminUsers());
        setSelectedUserId(null);
        setConversionHistory([]);
      }
    } catch (err) {
      setError('Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  const fetchUserConversionHistory = async (userId) => {
    setLoading(true);
    setError('');
    try {
      setConversionHistory(await getUserConversionHistory(userId));
    } catch (err) {
      setError('Failed to fetch conversion history');
    } finally {
      setLoading(false);
    }
  };

  const handleUserSelectionChange = (userId) => {
    setSelectedUserId(userId);
    if (userId) {
      fetchUserConversionHistory(userId);
    } else {
      setConversionHistory([]);
    }
  };

  const showMessage = (msg, isError = false) => {
    if (isError) setError(msg);
    else setSuccess(msg);
    setTimeout(() => {
      setError('');
      setSuccess('');
    }, 3000);
  };

  // User operations
  const handleAddUser = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await addAdminUser(userForm);
      setShowUserModal(false);
      setUserForm({ email: '', name: '', password: '' });
      showMessage('User added successfully');
      fetchData();
    } catch (err) {
      showMessage(err.message || 'Failed to add user', true);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateUser = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateAdminUser(editingUser.id, userForm);
      setEditingUser(null);
      setUserForm({ email: '', name: '', password: '' });
      showMessage('User updated successfully');
      fetchData();
    } catch (err) {
      showMessage(err.message || 'Failed to update user', true);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (id) => {
    if (!confirm('Are you sure you want to delete this user?')) return;
    setLoading(true);
    try {
      await deleteAdminUser(id);
      showMessage('User deleted successfully');
      fetchData();
    } catch (err) {
      showMessage(err.message || 'Failed to delete user', true);
    } finally {
      setLoading(false);
    }
  };

  // Currency operations
  const handleAddCurrency = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await addCurrency(currencyForm);
      setShowCurrencyModal(false);
      setCurrencyForm({ code: '', name: '', flag: '' });
      showMessage('Currency added successfully');
      fetchData();
    } catch (err) {
      showMessage(err.message || 'Failed to add currency', true);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateCurrency = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateCurrency(editingCurrency.code, currencyForm);
      setEditingCurrency(null);
      setCurrencyForm({ code: '', name: '', flag: '' });
      showMessage('Currency updated successfully');
      fetchData();
    } catch (err) {
      showMessage(err.message || 'Failed to update currency', true);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteCurrency = async (code) => {
    if (!confirm('Are you sure you want to delete this currency?')) return;
    setLoading(true);
    try {
      await deleteCurrency(code);
      showMessage('Currency deleted successfully');
      fetchData();
    } catch (err) {
      showMessage(err.message || 'Failed to delete currency', true);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleCurrency = async (code, active) => {
    try {
      await updateCurrency(code, { active: !active });
      showMessage(`Currency ${!active ? 'enabled' : 'disabled'} successfully`);
      fetchData();
    } catch (err) {
      showMessage('Failed to update currency', true);
    }
  };

  const handleForceLogout = async (userId) => {
    if (!confirm('Are you sure you want to force logout this user?')) return;
    setLoading(true);
    try {
      await forceLogout(userId);
      showMessage('User forced to logout successfully');
      fetchData();
    } catch (err) {
      showMessage(err.message || 'Failed to force logout', true);
    } finally {
      setLoading(false);
    }
  };

  const openEditUser = (user) => {
    setEditingUser(user);
    setUserForm({ email: user.email, name: user.name, password: '' });
  };

  const openEditCurrency = (currency) => {
    setEditingCurrency(currency);
    setCurrencyForm({ code: currency.code, name: currency.name, flag: currency.flag });
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950">
      {/* Header */}
      <header className="bg-white dark:bg-slate-900 shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <LayoutDashboard className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">Admin Dashboard</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-600 dark:text-slate-300">Welcome, {admin.name}</span>
            <button 
              onClick={onLogout}
              className="flex items-center gap-2 px-4 py-2 bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 rounded-xl hover:bg-rose-200 dark:hover:bg-rose-900/50 transition-all"
            >
              <LogOut size={18} />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </header>

      {/* Messages */}
      {error && (
        <div className="max-w-7xl mx-auto px-4 mt-4">
          <div className="p-4 bg-rose-100 dark:bg-rose-900/30 border border-rose-300 dark:border-rose-700 rounded-xl text-rose-600 dark:text-rose-400">
            {error}
          </div>
        </div>
      )}
      {success && (
        <div className="max-w-7xl mx-auto px-4 mt-4">
          <div className="p-4 bg-green-100 dark:bg-green-900/30 border border-green-300 dark:border-green-700 rounded-xl text-green-600 dark:text-green-400">
            {success}
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="max-w-7xl mx-auto px-4 mt-6">
        <div className="flex gap-4">
          <button
            onClick={() => setActiveTab('users')}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${
              activeTab === 'users' 
                ? 'bg-indigo-600 text-white' 
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <Users size={20} />
            Users
          </button>
          <button
            onClick={() => setActiveTab('currencies')}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${
              activeTab === 'currencies' 
                ? 'bg-indigo-600 text-white' 
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <DollarSign size={20} />
            Currencies
          </button>
          <button
            onClick={() => setActiveTab('loggedIn')}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${
              activeTab === 'loggedIn' 
                ? 'bg-indigo-600 text-white' 
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <LogIn size={20} />
            Logged In Users
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${
              activeTab === 'history' 
                ? 'bg-indigo-600 text-white' 
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            <History size={20} />
            Conversion History
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="animate-spin text-indigo-600" size={40} />
          </div>
        ) : activeTab === 'users' ? (
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-lg overflow-hidden">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">User Management</h2>
              <button
                onClick={() => { setShowUserModal(true); setUserForm({ email: '', name: '', password: '' }); }}
                className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all"
              >
                <Plus size={18} />
                Add User
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 dark:bg-slate-800">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">ID</th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">Name</th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">Email</th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">Role</th>
                    <th className="px-6 py-4 text-right text-sm font-bold text-slate-600 dark:text-slate-300">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {users.map(user => (
                    <tr key={user.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td className="px-6 py-4 text-slate-900 dark:text-white">{user.id}</td>
                      <td className="px-6 py-4 text-slate-900 dark:text-white font-medium">{user.name}</td>
                      <td className="px-6 py-4 text-slate-600 dark:text-slate-300">{user.email}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                          user.role === 'admin' 
                            ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400' 
                            : 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400'
                        }`}>
                          {user.role}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => openEditUser(user)}
                            className="p-2 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-lg transition-all"
                          >
                            <Pencil size={18} />
                          </button>
                          {user.role !== 'admin' && (
                            <button
                              onClick={() => handleDeleteUser(user.id)}
                              className="p-2 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-lg transition-all"
                            >
                              <Trash2 size={18} />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : activeTab === 'currencies' ? (
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-lg overflow-hidden">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">Currency Management</h2>
              <button
                onClick={() => { setShowCurrencyModal(true); setCurrencyForm({ code: '', name: '', flag: '' }); }}
                className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all"
              >
                <Plus size={18} />
                Add Currency
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 dark:bg-slate-800">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">Flag</th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">Code</th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">Name</th>
                    <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">Status</th>
                    <th className="px-6 py-4 text-right text-sm font-bold text-slate-600 dark:text-slate-300">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {currencies.map(currency => (
                    <tr key={currency.code} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td className="px-6 py-4 text-2xl">{currency.flag}</td>
                      <td className="px-6 py-4 text-slate-900 dark:text-white font-bold">{currency.code}</td>
                      <td className="px-6 py-4 text-slate-600 dark:text-slate-300">{currency.name}</td>
                      <td className="px-6 py-4">
                        <button
                          onClick={() => handleToggleCurrency(currency.code, currency.active)}
                          className={`px-3 py-1 rounded-full text-xs font-bold ${
                            currency.active 
                              ? 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400' 
                              : 'bg-slate-100 dark:bg-slate-700 text-slate-500'
                          }`}
                        >
                          {currency.active ? 'Active' : 'Inactive'}
                        </button>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => openEditCurrency(currency)}
                            className="p-2 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-lg transition-all"
                          >
                            <Pencil size={18} />
                          </button>
                          <button
                            onClick={() => handleDeleteCurrency(currency.code)}
                            className="p-2 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-lg transition-all"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : activeTab === 'loggedIn' ? (
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-lg overflow-hidden">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">Currently Logged In Users</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Manage users who are currently active in the system</p>
            </div>
            {loggedInUsers.length === 0 ? (
              <div className="p-12 text-center">
                <LogIn className="w-16 h-16 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
                <p className="text-slate-500 dark:text-slate-400">No users are currently logged in</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-50 dark:bg-slate-800">
                    <tr>
                      <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">ID</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">Name</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">Email</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">Login Time</th>
                      <th className="px-6 py-4 text-right text-sm font-bold text-slate-600 dark:text-slate-300">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {loggedInUsers.map(user => (
                      <tr key={user.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                        <td className="px-6 py-4 text-slate-900 dark:text-white">{user.id}</td>
                        <td className="px-6 py-4 text-slate-900 dark:text-white font-medium">{user.name}</td>
                        <td className="px-6 py-4 text-slate-600 dark:text-slate-300">{user.email}</td>
                        <td className="px-6 py-4 text-slate-600 dark:text-slate-300">
                          {new Date(user.loginTime).toLocaleString()}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button
                            onClick={() => handleForceLogout(user.id)}
                            className="flex items-center gap-2 px-4 py-2 bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 rounded-xl hover:bg-rose-200 dark:hover:bg-rose-900/50 transition-all"
                          >
                            <LogOut size={16} />
                            Force Logout
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-lg overflow-hidden">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">Conversion History</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">View conversion history for individual users</p>
              
              <div className="mt-6">
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-3">Select User</label>
                <select
                  value={selectedUserId || ''}
                  onChange={(e) => handleUserSelectionChange(e.target.value ? Number(e.target.value) : null)}
                  className="w-full px-4 py-3 rounded-xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none text-slate-900 dark:text-white"
                >
                  <option value="">-- Select a user --</option>
                  {users.map(user => (
                    <option key={user.id} value={user.id}>
                      {user.name} ({user.email})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {!selectedUserId ? (
              <div className="p-12 text-center">
                <History className="w-16 h-16 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
                <p className="text-slate-500 dark:text-slate-400">Select a user to view their conversion history</p>
              </div>
            ) : conversionHistory.length === 0 ? (
              <div className="p-12 text-center">
                <History className="w-16 h-16 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
                <p className="text-slate-500 dark:text-slate-400">No conversion history for this user</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-50 dark:bg-slate-800">
                    <tr>
                      <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">From</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">To</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">Amount</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">Result</th>
                      <th className="px-6 py-4 text-left text-sm font-bold text-slate-600 dark:text-slate-300">Date & Time</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {conversionHistory.map(record => (
                      <tr key={record.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                        <td className="px-6 py-4 text-slate-900 dark:text-white font-bold">{record.from_currency}</td>
                        <td className="px-6 py-4 text-slate-900 dark:text-white font-bold">{record.to_currency}</td>
                        <td className="px-6 py-4 text-slate-600 dark:text-slate-300">{record.amount}</td>
                        <td className="px-6 py-4 text-slate-600 dark:text-slate-300">{Number(record.result).toFixed(2)}</td>
                        <td className="px-6 py-4 text-slate-600 dark:text-slate-300 text-sm">
                          {new Date(record.timestamp).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>

      {/* User Modal */}
      {showUserModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-md p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">Add New User</h3>
              <button onClick={() => setShowUserModal(false)} className="text-slate-400 hover:text-slate-600">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleAddUser} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Name</label>
                <input
                  type="text"
                  value={userForm.name}
                  onChange={(e) => setUserForm({ ...userForm, name: e.target.value })}
                  className="w-full p-3 rounded-xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Email</label>
                <input
                  type="email"
                  value={userForm.email}
                  onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
                  className="w-full p-3 rounded-xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Password</label>
                <input
                  type="password"
                  value={userForm.password}
                  onChange={(e) => setUserForm({ ...userForm, password: e.target.value })}
                  className="w-full p-3 rounded-xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none"
                  required
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowUserModal(false)}
                  className="flex-1 py-3 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
                >
                  {loading ? <Loader2 className="animate-spin" size={20} /> : <Check size={20} />}
                  Add User
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {editingUser && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-md p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">Edit User</h3>
              <button onClick={() => setEditingUser(null)} className="text-slate-400 hover:text-slate-600">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleUpdateUser} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Name</label>
                <input
                  type="text"
                  value={userForm.name}
                  onChange={(e) => setUserForm({ ...userForm, name: e.target.value })}
                  className="w-full p-3 rounded-xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Email</label>
                <input
                  type="email"
                  value={userForm.email}
                  onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
                  className="w-full p-3 rounded-xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">New Password (leave blank to keep current)</label>
                <input
                  type="password"
                  value={userForm.password}
                  onChange={(e) => setUserForm({ ...userForm, password: e.target.value })}
                  className="w-full p-3 rounded-xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="flex-1 py-3 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
                >
                  {loading ? <Loader2 className="animate-spin" size={20} /> : <Check size={20} />}
                  Update User
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Currency Modal */}
      {showCurrencyModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-md p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">Add New Currency</h3>
              <button onClick={() => setShowCurrencyModal(false)} className="text-slate-400 hover:text-slate-600">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleAddCurrency} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Currency Code (e.g., USD)</label>
                <input
                  type="text"
                  value={currencyForm.code}
                  onChange={(e) => setCurrencyForm({ ...currencyForm, code: e.target.value.toUpperCase() })}
                  className="w-full p-3 rounded-xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none"
                  maxLength={3}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Currency Name</label>
                <input
                  type="text"
                  value={currencyForm.name}
                  onChange={(e) => setCurrencyForm({ ...currencyForm, name: e.target.value })}
                  className="w-full p-3 rounded-xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Flag Emoji</label>
                <input
                  type="text"
                  value={currencyForm.flag}
                  onChange={(e) => setCurrencyForm({ ...currencyForm, flag: e.target.value })}
                  className="w-full p-3 rounded-xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none"
                  required
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowCurrencyModal(false)}
                  className="flex-1 py-3 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
                >
                  {loading ? <Loader2 className="animate-spin" size={20} /> : <Check size={20} />}
                  Add Currency
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Currency Modal */}
      {editingCurrency && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-md p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">Edit Currency</h3>
              <button onClick={() => setEditingCurrency(null)} className="text-slate-400 hover:text-slate-600">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleUpdateCurrency} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Currency Code</label>
                <input
                  type="text"
                  value={currencyForm.code}
                  disabled
                  className="w-full p-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Currency Name</label>
                <input
                  type="text"
                  value={currencyForm.name}
                  onChange={(e) => setCurrencyForm({ ...currencyForm, name: e.target.value })}
                  className="w-full p-3 rounded-xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Flag Emoji</label>
                <input
                  type="text"
                  value={currencyForm.flag}
                  onChange={(e) => setCurrencyForm({ ...currencyForm, flag: e.target.value })}
                  className="w-full p-3 rounded-xl border-2 border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none"
                  required
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setEditingCurrency(null)}
                  className="flex-1 py-3 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
                >
                  {loading ? <Loader2 className="animate-spin" size={20} /> : <Check size={20} />}
                  Update Currency
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminDashboard;
