import { API_URL } from './config';

async function request(path, options = {}) {
  const response = await fetch(`${API_URL}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    ...options,
  });

  let payload = null;

  try {
    payload = await response.json();
  } catch {
    payload = null;
  }

  if (!response.ok) {
    throw new Error(payload?.error || payload?.message || 'Request failed');
  }

  return payload;
}

export function getActiveCurrencies() {
  return request('/currencies');
}

export function getAdminCurrencies() {
  return request('/admin/currencies');
}

export function getRates(base) {
  return request(`/rates/${encodeURIComponent(base)}`);
}

export function getRateHistory(base, target) {
  return request(`/history/${encodeURIComponent(base)}/${encodeURIComponent(target)}`);
}

export async function loginUser(email, password) {
  const response = await request('/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });

  return response.user;
}

export async function loginAdmin(email, password) {
  const response = await request('/admin/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });

  return response.user;
}

export async function registerUser({ name, email, password }) {
  const response = await request('/register', {
    method: 'POST',
    body: JSON.stringify({ name, email, password }),
  });

  return response.user;
}

export function logoutUser(userId) {
  return request('/logout', {
    method: 'POST',
    body: JSON.stringify({ userId }),
  });
}

export function getAdminUsers() {
  return request('/admin/users');
}

export function addAdminUser({ email, name, password }) {
  return request('/admin/users', {
    method: 'POST',
    body: JSON.stringify({ email, name, password }),
  });
}

export function updateAdminUser(id, updates) {
  return request(`/admin/users/${id}`, {
    method: 'PUT',
    body: JSON.stringify(updates),
  });
}

export function deleteAdminUser(id) {
  return request(`/admin/users/${id}`, {
    method: 'DELETE',
  });
}

export function addCurrency({ code, name, flag }) {
  return request('/admin/currencies', {
    method: 'POST',
    body: JSON.stringify({ code, name, flag }),
  });
}

export function updateCurrency(code, updates) {
  return request(`/admin/currencies/${encodeURIComponent(code)}`, {
    method: 'PUT',
    body: JSON.stringify(updates),
  });
}

export function deleteCurrency(code) {
  return request(`/admin/currencies/${encodeURIComponent(code)}`, {
    method: 'DELETE',
  });
}

export function getLoggedInUsers() {
  return request('/admin/logged-in-users');
}

export function forceLogout(userId) {
  return request('/admin/force-logout', {
    method: 'POST',
    body: JSON.stringify({ userId }),
  });
}

export function addConversion(payload) {
  return request('/conversion', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

export function getUserConversionHistory(userId) {
  return request(`/admin/conversion-history/${userId}`);
}
