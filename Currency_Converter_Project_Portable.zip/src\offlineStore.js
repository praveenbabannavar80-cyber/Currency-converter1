const STORAGE_KEYS = {
  users: 'offline_users',
  currencies: 'offline_currencies',
  loggedInUsers: 'offline_logged_in_users',
  conversionHistory: 'offline_conversion_history',
  nextUserId: 'offline_next_user_id',
  nextConversionId: 'offline_next_conversion_id',
};

const defaultUsers = [
  {
    id: 1,
    email: 'admin1234@gmail.com',
    password: 'Admin@123',
    name: 'Admin',
    role: 'admin',
    created_at: '2026-01-01T00:00:00.000Z',
  },
  {
    id: 2,
    email: 'user@currency.com',
    password: 'user123',
    name: 'User',
    role: 'user',
    created_at: '2026-01-01T00:00:00.000Z',
  },
];

const defaultCurrencies = [
  { code: 'AED', name: 'UAE Dirham', flag: 'AE', active: true },
  { code: 'ARS', name: 'Argentine Peso', flag: 'AR', active: true },
  { code: 'AUD', name: 'Australian Dollar', flag: 'AU', active: true },
  { code: 'BDT', name: 'Bangladeshi Taka', flag: 'BD', active: true },
  { code: 'BGN', name: 'Bulgarian Lev', flag: 'BG', active: true },
  { code: 'BHD', name: 'Bahraini Dinar', flag: 'BH', active: true },
  { code: 'BND', name: 'Brunei Dollar', flag: 'BN', active: true },
  { code: 'BOB', name: 'Bolivian Boliviano', flag: 'BO', active: true },
  { code: 'BRL', name: 'Brazilian Real', flag: 'BR', active: true },
  { code: 'BWP', name: 'Botswana Pula', flag: 'BW', active: true },
  { code: 'BYN', name: 'Belarusian Ruble', flag: 'BY', active: true },
  { code: 'CAD', name: 'Canadian Dollar', flag: 'CA', active: true },
  { code: 'CHF', name: 'Swiss Franc', flag: 'CH', active: true },
  { code: 'CLP', name: 'Chilean Peso', flag: 'CL', active: true },
  { code: 'CNY', name: 'Chinese Yuan', flag: 'CN', active: true },
  { code: 'COP', name: 'Colombian Peso', flag: 'CO', active: true },
  { code: 'CRC', name: 'Costa Rican Colon', flag: 'CR', active: true },
  { code: 'CZK', name: 'Czech Koruna', flag: 'CZ', active: true },
  { code: 'DKK', name: 'Danish Krone', flag: 'DK', active: true },
  { code: 'DOP', name: 'Dominican Peso', flag: 'DO', active: true },
  { code: 'DZD', name: 'Algerian Dinar', flag: 'DZ', active: true },
  { code: 'EGP', name: 'Egyptian Pound', flag: 'EG', active: true },
  { code: 'ETB', name: 'Ethiopian Birr', flag: 'ET', active: true },
  { code: 'EUR', name: 'Euro', flag: 'EU', active: true },
  { code: 'FJD', name: 'Fijian Dollar', flag: 'FJ', active: true },
  { code: 'GBP', name: 'British Pound Sterling', flag: 'GB', active: true },
  { code: 'GEL', name: 'Georgian Lari', flag: 'GE', active: true },
  { code: 'GHS', name: 'Ghanaian Cedi', flag: 'GH', active: true },
  { code: 'GTQ', name: 'Guatemalan Quetzal', flag: 'GT', active: true },
  { code: 'HKD', name: 'Hong Kong Dollar', flag: 'HK', active: true },
  { code: 'HNL', name: 'Honduran Lempira', flag: 'HN', active: true },
  { code: 'HUF', name: 'Hungarian Forint', flag: 'HU', active: true },
  { code: 'IDR', name: 'Indonesian Rupiah', flag: 'ID', active: true },
  { code: 'ILS', name: 'Israeli New Shekel', flag: 'IL', active: true },
  { code: 'INR', name: 'Indian Rupee', flag: 'IN', active: true },
  { code: 'ISK', name: 'Icelandic Krona', flag: 'IS', active: true },
  { code: 'JMD', name: 'Jamaican Dollar', flag: 'JM', active: true },
  { code: 'JOD', name: 'Jordanian Dinar', flag: 'JO', active: true },
  { code: 'JPY', name: 'Japanese Yen', flag: 'JP', active: true },
  { code: 'KES', name: 'Kenyan Shilling', flag: 'KE', active: true },
  { code: 'KRW', name: 'South Korean Won', flag: 'KR', active: true },
  { code: 'KWD', name: 'Kuwaiti Dinar', flag: 'KW', active: true },
  { code: 'KZT', name: 'Kazakhstani Tenge', flag: 'KZ', active: true },
  { code: 'LBP', name: 'Lebanese Pound', flag: 'LB', active: true },
  { code: 'LKR', name: 'Sri Lankan Rupee', flag: 'LK', active: true },
  { code: 'MAD', name: 'Moroccan Dirham', flag: 'MA', active: true },
  { code: 'MDL', name: 'Moldovan Leu', flag: 'MD', active: true },
  { code: 'MUR', name: 'Mauritian Rupee', flag: 'MU', active: true },
  { code: 'MXN', name: 'Mexican Peso', flag: 'MX', active: true },
  { code: 'MYR', name: 'Malaysian Ringgit', flag: 'MY', active: true },
  { code: 'NGN', name: 'Nigerian Naira', flag: 'NG', active: true },
  { code: 'NIO', name: 'Nicaraguan Cordoba', flag: 'NI', active: true },
  { code: 'NOK', name: 'Norwegian Krone', flag: 'NO', active: true },
  { code: 'NPR', name: 'Nepalese Rupee', flag: 'NP', active: true },
  { code: 'NZD', name: 'New Zealand Dollar', flag: 'NZ', active: true },
  { code: 'OMR', name: 'Omani Rial', flag: 'OM', active: true },
  { code: 'PEN', name: 'Peruvian Sol', flag: 'PE', active: true },
  { code: 'PHP', name: 'Philippine Peso', flag: 'PH', active: true },
  { code: 'PKR', name: 'Pakistani Rupee', flag: 'PK', active: true },
  { code: 'PLN', name: 'Polish Zloty', flag: 'PL', active: true },
  { code: 'QAR', name: 'Qatari Riyal', flag: 'QA', active: true },
  { code: 'RON', name: 'Romanian Leu', flag: 'RO', active: true },
  { code: 'RSD', name: 'Serbian Dinar', flag: 'RS', active: true },
  { code: 'RUB', name: 'Russian Ruble', flag: 'RU', active: true },
  { code: 'SAR', name: 'Saudi Riyal', flag: 'SA', active: true },
  { code: 'SEK', name: 'Swedish Krona', flag: 'SE', active: true },
  { code: 'SGD', name: 'Singapore Dollar', flag: 'SG', active: true },
  { code: 'THB', name: 'Thai Baht', flag: 'TH', active: true },
  { code: 'TND', name: 'Tunisian Dinar', flag: 'TN', active: true },
  { code: 'TRY', name: 'Turkish Lira', flag: 'TR', active: true },
  { code: 'TWD', name: 'New Taiwan Dollar', flag: 'TW', active: true },
  { code: 'TZS', name: 'Tanzanian Shilling', flag: 'TZ', active: true },
  { code: 'UAH', name: 'Ukrainian Hryvnia', flag: 'UA', active: true },
  { code: 'UGX', name: 'Ugandan Shilling', flag: 'UG', active: true },
  { code: 'USD', name: 'United States Dollar', flag: 'US', active: true },
  { code: 'UYU', name: 'Uruguayan Peso', flag: 'UY', active: true },
  { code: 'UZS', name: 'Uzbekistani Som', flag: 'UZ', active: true },
  { code: 'VND', name: 'Vietnamese Dong', flag: 'VN', active: true },
  { code: 'XAF', name: 'Central African CFA Franc', flag: 'CF', active: true },
  { code: 'XCD', name: 'East Caribbean Dollar', flag: 'AG', active: true },
  { code: 'XOF', name: 'West African CFA Franc', flag: 'SN', active: true },
  { code: 'YER', name: 'Yemeni Rial', flag: 'YE', active: true },
  { code: 'ZAR', name: 'South African Rand', flag: 'ZA', active: true },
  { code: 'ZMW', name: 'Zambian Kwacha', flag: 'ZM', active: true },
];

const offlineBaseRates = {
  AED: 3.6725, ARS: 880.0, AUD: 1.52, BDT: 117.0, BGN: 1.81, BHD: 0.376, BND: 1.35,
  BOB: 6.91, BRL: 5.14, BWP: 13.7, BYN: 3.27, CAD: 1.37, CHF: 0.91, CLP: 945.0,
  CNY: 7.24, COP: 3895.0, CRC: 510.0, CZK: 22.8, DKK: 6.9, DOP: 58.9, DZD: 134.5,
  EGP: 48.2, ETB: 57.3, EUR: 0.92, FJD: 2.24, GBP: 0.79, GEL: 2.71, GHS: 14.8,
  GTQ: 7.74, HKD: 7.82, HNL: 24.7, HUF: 361.0, IDR: 16120.0, ILS: 3.69, INR: 83.3,
  ISK: 138.4, JMD: 156.7, JOD: 0.709, JPY: 155.0, KES: 129.0, KRW: 1362.0, KWD: 0.307,
  KZT: 447.0, LBP: 89500.0, LKR: 301.0, MAD: 9.95, MDL: 17.8, MUR: 46.5, MXN: 16.9,
  MYR: 4.71, NGN: 1460.0, NIO: 36.8, NOK: 10.8, NPR: 133.3, NZD: 1.64, OMR: 0.384,
  PEN: 3.73, PHP: 57.1, PKR: 278.0, PLN: 3.96, QAR: 3.64, RON: 4.58, RSD: 107.8,
  RUB: 91.0, SAR: 3.75, SEK: 10.7, SGD: 1.35, THB: 36.7, TND: 3.12, TRY: 32.2,
  TWD: 32.4, TZS: 2580.0, UAH: 39.4, UGX: 3810.0, USD: 1, UYU: 39.0, UZS: 12750.0,
  VND: 25450.0, XAF: 603.0, XCD: 2.7, XOF: 603.0, YER: 250.0, ZAR: 18.4, ZMW: 26.4,
};

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function readJson(key, fallback) {
  const raw = localStorage.getItem(key);
  if (!raw) return clone(fallback);
  try {
    return JSON.parse(raw);
  } catch {
    return clone(fallback);
  }
}

function writeJson(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function sanitizeUser(user) {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
  };
}

function ensureInitialized() {
  if (!localStorage.getItem(STORAGE_KEYS.users)) {
    writeJson(STORAGE_KEYS.users, defaultUsers);
  }
  if (!localStorage.getItem(STORAGE_KEYS.currencies)) {
    writeJson(STORAGE_KEYS.currencies, defaultCurrencies);
  }
  if (!localStorage.getItem(STORAGE_KEYS.loggedInUsers)) {
    writeJson(STORAGE_KEYS.loggedInUsers, []);
  }
  if (!localStorage.getItem(STORAGE_KEYS.conversionHistory)) {
    writeJson(STORAGE_KEYS.conversionHistory, []);
  }
  if (!localStorage.getItem(STORAGE_KEYS.nextUserId)) {
    localStorage.setItem(STORAGE_KEYS.nextUserId, '3');
  }
  if (!localStorage.getItem(STORAGE_KEYS.nextConversionId)) {
    localStorage.setItem(STORAGE_KEYS.nextConversionId, '1');
  }
}

function getUsers() {
  ensureInitialized();
  return readJson(STORAGE_KEYS.users, defaultUsers);
}

function saveUsers(users) {
  writeJson(STORAGE_KEYS.users, users);
}

function getCurrenciesRaw() {
  ensureInitialized();
  return readJson(STORAGE_KEYS.currencies, defaultCurrencies);
}

function saveCurrencies(currencies) {
  writeJson(STORAGE_KEYS.currencies, currencies);
}

function getLoggedInUsersRaw() {
  ensureInitialized();
  return readJson(STORAGE_KEYS.loggedInUsers, []);
}

function saveLoggedInUsers(users) {
  writeJson(STORAGE_KEYS.loggedInUsers, users);
}

function getConversionHistoryRaw() {
  ensureInitialized();
  return readJson(STORAGE_KEYS.conversionHistory, []);
}

function saveConversionHistory(history) {
  writeJson(STORAGE_KEYS.conversionHistory, history);
}

function nextId(key) {
  ensureInitialized();
  const current = Number(localStorage.getItem(key) || '1');
  localStorage.setItem(key, String(current + 1));
  return current;
}

function throwError(message) {
  throw new Error(message);
}

export function getActiveCurrencies() {
  return Promise.resolve(getCurrenciesRaw().filter((currency) => currency.active));
}

export function getAdminCurrencies() {
  return Promise.resolve(getCurrenciesRaw());
}

export function getRates(base) {
  const normalizedBase = String(base || '').toUpperCase();
  const baseValue = offlineBaseRates[normalizedBase];

  if (!baseValue) {
    throwError(`Unsupported base currency: ${normalizedBase}`);
  }

  const rates = Object.fromEntries(
    Object.entries(offlineBaseRates).map(([code, usdRate]) => [code, usdRate / baseValue])
  );

  return Promise.resolve({
    base: normalizedBase,
    date: new Date().toISOString().split('T')[0],
    offline: true,
    rates,
  });
}

export function getRateHistory(base, target, days = 30) {
  const normalizedTarget = String(target || '').toUpperCase();

  return getRates(base).then((response) => {
    const currentRate = response.rates[normalizedTarget];

    if (!currentRate) {
      throwError(`Unsupported currency pair: ${String(base).toUpperCase()} to ${normalizedTarget}`);
    }

    const history = [];
    for (let offset = days - 1; offset >= 0; offset -= 1) {
      const date = new Date();
      date.setDate(date.getDate() - offset);

      const wave = Math.sin((days - offset) / 4) * 0.012;
      const drift = ((days - offset) / days - 0.5) * 0.01;

      history.push({
        date: date.toISOString().split('T')[0],
        rate: Number((currentRate * (1 + wave + drift)).toFixed(6)),
      });
    }

    return history;
  });
}

export function loginUser(email, password) {
  const user = getUsers().find(
    (entry) => entry.email === email && entry.password === password && entry.role === 'user'
  );

  if (!user) {
    throwError('Invalid credentials');
  }

  const loggedInUsers = getLoggedInUsersRaw();
  if (!loggedInUsers.some((entry) => entry.id === user.id)) {
    loggedInUsers.push({
      ...sanitizeUser(user),
      loginTime: new Date().toISOString(),
    });
    saveLoggedInUsers(loggedInUsers);
  }

  return Promise.resolve(sanitizeUser(user));
}

export function loginAdmin(email, password) {
  const user = getUsers().find(
    (entry) => entry.email === email && entry.password === password && entry.role === 'admin'
  );

  if (!user) {
    throwError('Invalid admin credentials');
  }

  return Promise.resolve(sanitizeUser(user));
}

export function registerUser({ name, email, password }) {
  const users = getUsers();

  if (users.some((entry) => entry.email.toLowerCase() === email.toLowerCase())) {
    throwError('Email already exists');
  }

  const newUser = {
    id: nextId(STORAGE_KEYS.nextUserId),
    name,
    email,
    password,
    role: 'user',
    created_at: new Date().toISOString(),
  };

  users.push(newUser);
  saveUsers(users);
  return Promise.resolve(sanitizeUser(newUser));
}

export function logoutUser(userId) {
  saveLoggedInUsers(getLoggedInUsersRaw().filter((entry) => entry.id !== userId));
  return Promise.resolve({ success: true });
}

export function getAdminUsers() {
  return Promise.resolve(getUsers().map((user) => ({ ...sanitizeUser(user), password: '***' })));
}

export function addAdminUser({ email, name, password }) {
  if (!email || !name || !password) {
    throwError('All fields are required');
  }
  return registerUser({ email, name, password }).then((user) => ({ ...user, password: '***' }));
}

export function updateAdminUser(id, updates) {
  const users = getUsers();
  const index = users.findIndex((user) => user.id === Number(id));

  if (index === -1) {
    throwError('User not found');
  }

  if (
    updates.email &&
    users.some((user) => user.id !== Number(id) && user.email.toLowerCase() === updates.email.toLowerCase())
  ) {
    throwError('Email already exists');
  }

  const current = users[index];
  users[index] = {
    ...current,
    email: updates.email || current.email,
    name: updates.name || current.name,
    password: updates.password || current.password,
  };

  saveUsers(users);
  return Promise.resolve({ ...sanitizeUser(users[index]), password: '***' });
}

export function deleteAdminUser(id) {
  const users = getUsers();
  const user = users.find((entry) => entry.id === Number(id));

  if (!user) {
    throwError('User not found');
  }
  if (user.role === 'admin') {
    throwError('Cannot delete admin');
  }

  saveUsers(users.filter((entry) => entry.id !== Number(id)));
  saveLoggedInUsers(getLoggedInUsersRaw().filter((entry) => entry.id !== Number(id)));
  saveConversionHistory(getConversionHistoryRaw().filter((entry) => entry.user_id !== Number(id)));
  return Promise.resolve({ success: true });
}

export function addCurrency({ code, name, flag }) {
  const currencies = getCurrenciesRaw();
  const normalizedCode = String(code || '').toUpperCase();

  if (!normalizedCode || normalizedCode.length !== 3) {
    throwError('Currency code must be 3 letters');
  }
  if (currencies.some((currency) => currency.code === normalizedCode)) {
    throwError('Currency code already exists');
  }

  const currency = { code: normalizedCode, name, flag, active: true };
  currencies.push(currency);
  saveCurrencies(currencies);
  return Promise.resolve(currency);
}

export function updateCurrency(code, updates) {
  const currencies = getCurrenciesRaw();
  const index = currencies.findIndex((currency) => currency.code === String(code).toUpperCase());

  if (index === -1) {
    throwError('Currency not found');
  }

  currencies[index] = {
    ...currencies[index],
    ...(updates.name ? { name: updates.name } : {}),
    ...(updates.flag ? { flag: updates.flag } : {}),
    ...(typeof updates.active === 'boolean' ? { active: updates.active } : {}),
  };

  saveCurrencies(currencies);
  return Promise.resolve(currencies[index]);
}

export function deleteCurrency(code) {
  const currencies = getCurrenciesRaw();
  const filtered = currencies.filter((currency) => currency.code !== String(code).toUpperCase());

  if (filtered.length === currencies.length) {
    throwError('Currency not found');
  }

  saveCurrencies(filtered);
  return Promise.resolve({ success: true });
}

export function getLoggedInUsers() {
  return Promise.resolve(getLoggedInUsersRaw());
}

export function forceLogout(userId) {
  const before = getLoggedInUsersRaw();
  const after = before.filter((entry) => entry.id !== Number(userId));

  if (before.length === after.length) {
    throwError('User not found in logged-in list');
  }

  saveLoggedInUsers(after);
  return Promise.resolve({ success: true });
}

export function addConversion({ user_id, from_currency, to_currency, amount, result, timestamp }) {
  const history = getConversionHistoryRaw();
  const record = {
    id: nextId(STORAGE_KEYS.nextConversionId),
    user_id: Number(user_id),
    from_currency,
    to_currency,
    amount,
    result,
    timestamp: timestamp || new Date().toISOString(),
  };

  history.unshift(record);
  saveConversionHistory(history.slice(0, 1000));
  return Promise.resolve(record);
}

export function getUserConversionHistory(userId) {
  return Promise.resolve(
    getConversionHistoryRaw()
      .filter((entry) => entry.user_id === Number(userId))
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
      .slice(0, 500)
  );
}

ensureInitialized();
