import React from 'react';
import { ArrowLeft, AlertCircle, RefreshCw, X } from 'lucide-react';

function formatSplitAmount(value) {
  return Number(value || 0).toFixed(2);
}

export default function SpecialFeaturesPage({
  currencies,
  splitAmount,
  setSplitAmount,
  splitCurrency,
  setSplitCurrency,
  splitPeople,
  setSplitPeople,
  splitTargets,
  splitLoading,
  splitError,
  splitPreview,
  perPersonBaseAmount,
  handleSplitTargetChange,
  addSplitTarget,
  removeSplitTarget,
  onBack,
}) {
  return (
    <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
      <div className="w-full max-w-5xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800 transition-all">
        <div className="p-6 md:p-8 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-amber-500/10 to-orange-500/10">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.25em] text-amber-600 dark:text-amber-400">
              Special Features
            </p>
            <h1 className="mt-2 text-2xl md:text-3xl font-black text-slate-900 dark:text-white">
              Expense Split in Multiple Currencies
            </h1>
            <p className="mt-2 text-slate-600 dark:text-slate-300">
              Split one bill equally and preview each person&apos;s share across multiple currencies.
            </p>
          </div>
          <button
            onClick={onBack}
            className="inline-flex items-center gap-2 px-4 py-3 rounded-2xl bg-white dark:bg-slate-800 shadow-md text-slate-700 dark:text-slate-200 hover:scale-105 transition-all"
          >
            <ArrowLeft size={18} />
            Back to Converter
          </button>
        </div>

        <div className="p-6 md:p-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2 md:col-span-2">
              <label className="text-sm font-semibold text-slate-700 dark:text-slate-300">Expense Amount</label>
              <input
                type="number"
                min="0"
                value={splitAmount}
                onChange={(e) => setSplitAmount(Number(e.target.value))}
                className="w-full p-4 rounded-2xl border-2 border-amber-100 dark:border-amber-900/50 bg-white dark:bg-slate-950 outline-none focus:border-amber-400 transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700 dark:text-slate-300">Base Currency</label>
              <select
                value={splitCurrency}
                onChange={(e) => setSplitCurrency(e.target.value)}
                className="w-full p-4 rounded-2xl border-2 border-amber-100 dark:border-amber-900/50 bg-white dark:bg-slate-950 outline-none focus:border-amber-400 transition-all"
              >
                {currencies.map((curr) => (
                  <option key={curr.code} value={curr.code}>{curr.flag} {curr.code} - {curr.name}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700 dark:text-slate-300">People</label>
              <input
                type="number"
                min="1"
                value={splitPeople}
                onChange={(e) => setSplitPeople(Math.max(1, Number(e.target.value) || 1))}
                className="w-full p-4 rounded-2xl border-2 border-amber-100 dark:border-amber-900/50 bg-white dark:bg-slate-950 outline-none focus:border-amber-400 transition-all"
              />
            </div>
          </div>

          <div className="rounded-3xl border border-amber-200 dark:border-amber-900/60 bg-gradient-to-br from-amber-50 via-white to-orange-50 dark:from-amber-950/30 dark:via-slate-900 dark:to-orange-950/30 p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">Per person share</p>
                <p className="mt-2 text-3xl font-black text-amber-600 dark:text-amber-300">
                  {formatSplitAmount(perPersonBaseAmount)} {splitCurrency}
                </p>
              </div>
              <button
                onClick={addSplitTarget}
                disabled={splitTargets.length >= 5}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-semibold transition-all"
              >
                Add Currency
              </button>
            </div>

            <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-3">
              {splitTargets.map((target, index) => (
                <div key={`${target}-${index}`} className="flex gap-2">
                  <select
                    value={target}
                    onChange={(e) => handleSplitTargetChange(index, e.target.value)}
                    className="flex-1 p-3 rounded-2xl border-2 border-amber-100 dark:border-amber-900/50 bg-white/90 dark:bg-slate-950 outline-none focus:border-amber-400 transition-all"
                  >
                    {currencies.map((curr) => (
                      <option key={curr.code} value={curr.code}>{curr.code} - {curr.name}</option>
                    ))}
                  </select>
                  <button
                    onClick={() => removeSplitTarget(index)}
                    disabled={splitTargets.length <= 1}
                    className="px-3 rounded-2xl bg-white dark:bg-slate-950 border border-amber-100 dark:border-amber-900/50 text-rose-500 disabled:text-slate-300 disabled:cursor-not-allowed"
                    title="Remove currency"
                  >
                    <X size={18} />
                  </button>
                </div>
              ))}
            </div>

            <div className="mt-6">
              {splitLoading ? (
                <div className="flex items-center justify-center py-10">
                  <RefreshCw className="animate-spin text-amber-500" size={28} />
                </div>
              ) : splitError ? (
                <div className="flex items-center gap-2 rounded-2xl bg-rose-50 dark:bg-rose-950/30 px-4 py-3 text-rose-600 dark:text-rose-300">
                  <AlertCircle size={18} />
                  <span>{splitError}</span>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {splitPreview.map((item) => (
                    <div key={item.code} className="rounded-2xl border border-amber-100 dark:border-amber-900/50 bg-white/80 dark:bg-slate-950/70 p-4">
                      <p className="text-xs uppercase tracking-[0.2em] text-slate-500 dark:text-slate-400">
                        {item.flag} {item.code}
                      </p>
                      <p className="mt-2 text-2xl font-black text-slate-900 dark:text-white">
                        {formatSplitAmount(item.amount)}
                      </p>
                      <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{item.name}</p>
                      <p className="mt-3 text-xs text-slate-400">
                        Each of {splitPeople} people pays this amount.
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
